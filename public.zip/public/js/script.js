// const container = document.getElementById("editor");

// const quill = new Quill(container, {
//   theme: "snow",
// });

// const el = document.querySelector("#editor");

// el.onclick = () => {
//   console.log("I am clicked");
// };
