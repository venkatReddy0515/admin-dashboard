// ------------------------
// postcss.config.js
// (placed in frontend root)
// ------------------------
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
