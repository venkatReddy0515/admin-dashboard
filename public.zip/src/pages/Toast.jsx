import React, { useEffect } from 'react';

function Toast({ type, message, onClose }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  let progressColor;
  switch (type) {
    case 'success':
      progressColor = 'green';
      break;
    case 'processing':
      progressColor = 'goldenrod';
      break;
    case 'failed':
      progressColor = 'red';
      break;
    default:
      progressColor = 'gray';
  }

  return (
    <div
      style={{
        position: 'relative',
        padding: '10px',
        border: '1px solid #ccc',
        borderRadius: '5px',
        marginBottom: '10px',
        overflow: 'hidden',
      }}
    >
      <span>{message}</span>
      <button
        onClick={onClose}
        style={{
          position: 'absolute',
          top: '5px',
          right: '5px',
          background: 'transparent',
          border: 'none',
          cursor: 'pointer',
          fontSize: '16px',
        }}
      >
        &times;
      </button>
      <div
        style={{
          position: 'absolute',
          bottom: '0',
          right: '0',
          height: '4px',
          backgroundColor: progressColor,
          animation: 'progressAnimation 3s linear forwards',
        }}
      />
      <style>{`
        @keyframes progressAnimation {
          from { width: 0%; }
          to { width: 100%; }
        }
      `}</style>
    </div>
  );
}

export default Toast;
