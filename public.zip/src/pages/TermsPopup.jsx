import React, { useState } from 'react';

function TermsPopup() {
  const [open, setOpen] = useState(true);
  const [accepted, setAccepted] = useState(false);
  const [termsChecked, setTermsChecked] = useState(false);
  const [privacyChecked, setPrivacyChecked] = useState(false);

  const handleAccept = () => {
    if (termsChecked && privacyChecked) {
      setAccepted(true);
      setOpen(false);
    }
  };

  return (
    <div>
      {accepted && (
        <div style={{ textAlign: 'center', marginTop: '20px' }}>
          <p style={{ color: 'green', fontWeight: 'bold' }}>
            Terms and Conditions and Privacy Policy Accepted!
          </p>
        </div>
      )}
      {open && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <div
            style={{
              backgroundColor: 'white',
              padding: '20px',
              borderRadius: '8px',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.3)',
              width: '300px',
            }}
          >
            <h2>Terms and Conditions</h2>
            <p>Please read and accept the following to proceed:</p>
            <div style={{ margin: '10px 0', display: 'flex', alignItems: 'center' }}>
              <input
                type="checkbox"
                id="terms"
                checked={termsChecked}
                onChange={(e) => setTermsChecked(e.target.checked)}
              />
              <label htmlFor="terms" style={{ marginLeft: '8px' }}>
                I accept the terms and conditions.
              </label>
            </div>
            <div style={{ margin: '10px 0', display: 'flex', alignItems: 'center' }}>
              <input
                type="checkbox"
                id="privacy"
                checked={privacyChecked}
                onChange={(e) => setPrivacyChecked(e.target.checked)}
              />
              <label htmlFor="privacy" style={{ marginLeft: '8px' }}>
                I accept the privacy policy.
              </label>
            </div>
            <button onClick={handleAccept} disabled={!(termsChecked && privacyChecked)}>
              Accept
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default TermsPopup;
