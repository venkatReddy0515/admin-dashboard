import React, { useState } from 'react';
import Toast from './Toast';

function ToastNotification() {
  // Group toasts by type in an object
  const [toasts, setToasts] = useState({
    success: [],
    processing: [],
    failed: [],
  });

  // Separate state for input fields for each section
  const [messageSuccess, setMessageSuccess] = useState('');
  const [messageProcessing, setMessageProcessing] = useState('');
  const [messageFailed, setMessageFailed] = useState('');

  // Function to add a toast for a specific type
  const addToast = (type, message) => {
    if (message.trim() === '') return;

    const newToast = {
      id: Date.now(),
      type,
      message,
    };

    setToasts((prev) => ({
      ...prev,
      [type]: [...prev[type], newToast],
    }));

    // Clear the input field for the given type
    if (type === 'success') setMessageSuccess('');
    if (type === 'processing') setMessageProcessing('');
    if (type === 'failed') setMessageFailed('');
  };

  // Function to remove a toast from a specific type
  const removeToast = (type, id) => {
    setToasts((prev) => ({
      ...prev,
      [type]: prev[type].filter((toast) => toast.id !== id),
    }));
  };

  // Render a section for a given type
  const renderSection = (type, message, setMessage, label) => (
    <div className="w-1/3 p-4">
      <h3 className="text-xl font-semibold mb-2">{label}</h3>
      <input
        type="text"
        placeholder={`Enter ${label.toLowerCase()} message`}
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        className="p-2 mb-2 w-full border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
      <button
        onClick={() => addToast(type, message)}
        className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
      >
        Show
      </button>
      {/* Toast container: fixed positioned at top-right */}
      <div className="mt-2 fixed top-[70px] right-5 w-64 space-y-2">
        {toasts[type].map((toast) => (
          <Toast
            key={toast.id}
            type={toast.type}
            message={toast.message}
            onClose={() => removeToast(type, toast.id)}
          />
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-5 font-sans">
      <h2 className="text-2xl font-bold mb-4">Toast Notification Demo</h2>
      <div className="flex justify-between">
        {renderSection('success', messageSuccess, setMessageSuccess, 'Success')}
        {renderSection('processing', messageProcessing, setMessageProcessing, 'Processing')}
        {renderSection('failed', messageFailed, setMessageFailed, 'Failed')}
      </div>
    </div>
  );
}

export default ToastNotification;
