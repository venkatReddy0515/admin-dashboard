import React, { useState } from "react";
import SettingsInfo from "./SettingsInfo";
import TermsPopup from "./TermsPopup";
import ToastNotification from "./ToastNofications";
import AdminPanel from "./Panel";
const WebsiteManager = () => {
  const [currentTab, setCurrentTab] = useState("settings");

  

  return (
    <div className="p-4 space-y-8">
      {/* Tab Navigation */}
      <nav className="flex justify-center gap-14 fixed top-11 p-4 rounded-md">
        <button
          onClick={() => setCurrentTab("settings")}
          className={`px-4 py-2 ${currentTab === "settings" ? "bg-blue-500 text-white" : "bg-white"}`}
        >
          Settings
        </button>
        <button
          onClick={() => setCurrentTab("notifications")}
          className={`px-4 py-2 ${currentTab === "notifications" ? "bg-blue-500 text-white" : "bg-white"}`}
        >
          Notifications
        </button>
        <button
          onClick={() => setCurrentTab("terms")}
          className={`px-4 py-2 ${currentTab === "terms" ? "bg-blue-500 text-white" : "bg-white"}`}
        >
          Terms and Conditions
        </button>
        <button
          onClick={() => setCurrentTab("status")}
          className={`px-4 py-2 ${currentTab === "status" ? "bg-blue-500 text-white" : "bg-white"}`}
        >
          Site Status
        </button>
      </nav>

      {/* Tab Content */}
      {currentTab === "settings" && (
        <>
        <SettingsInfo/>
        </>
        
      )}

      {currentTab === "status" && (
        <>
        <AdminPanel/>
        </>
        
      )}
      {currentTab === "notifications" && (
        <ToastNotification/>
      )}

      {currentTab === "terms" && (
        <TermsPopup/>
      )}
    </div>
  );
};

export default WebsiteManager;
