import React, { useState } from "react";
import { FaEdit, FaTrash } from "react-icons/fa";
import LeftNavbar from "./LeftNavbar";
import RightPanel from "./TempleteEdit"
export default function Help({ setCurrentPage }) {

  return (
    <div className="p-1 space-y-4">
       <div>
        
        <LeftNavbar/>
        {/* <RightPanel/> */}
      </div>
      
    </div>
  );
}
