import React from 'react'
import ManageOrders from '../components/ClaimRestaurant/ManageOrders'


const ClaimRestaurant = () => {
  return (
    <div>
      <ManageOrders />
    </div>
  )
}

export default ClaimRestaurant;
