import { useState } from 'react';

function SettingsInfo() {
    const [websiteName, setWebsiteName] = useState('My Website');
    const [websiteLogo, setWebsiteLogo] = useState('https://via.placeholder.com/150');
    const [timeZone, setTimeZone] = useState('UTC');
    const [language, setLanguage] = useState('English');

    const handleNameChange = (e) => setWebsiteName(e.target.value);
    const handleLogoChange = (e) => setWebsiteLogo(URL.createObjectURL(e.target.files[0]));
    const handleTimeZoneChange = (e) => setTimeZone(e.target.value);
    const handleLanguageChange = (e) => setLanguage(e.target.value);

    const handleSubmit = (e) => {
        e.preventDefault();
        alert('Settings updated successfully!');
    };

    return (
        <section className="p-6 w-full mx-auto border rounded-2xl shadow-lg bg-white">
            <div className="flex justify-center mb-6">
                <img src={websiteLogo} alt="Website Logo" className="w-32 h-32 rounded-full shadow-lg" />
            </div>
            <form onSubmit={handleSubmit} className="space-y-8">
                <div>
                    <label className="block mb-3 font-medium text-lg">Website Name:</label>
                    <input
                        type="text"
                        value={websiteName}
                        onChange={handleNameChange}
                        className="w-full p-4 border rounded-xl shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-12"
                        required
                    />
                </div>
                <div>
                    <label className="block mb-3 font-medium text-lg">Upload Logo:</label>
                    <input
                        type="file"
                        accept='image/*'
                        onChange={handleLogoChange}
                        className="w-full p-4 border rounded-xl shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-12"
                    />
                </div>
                <div>
                    <label className="block mb-3 font-medium text-lg">Time Zone:</label>
                    <input
                        type="text"
                        value={timeZone}
                        onChange={handleTimeZoneChange}
                        className="w-full p-4 border rounded-xl shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-12"
                        required
                    />
                </div>
                <div>
                    <label className="block mb-3 font-medium text-lg">Language:</label>
                    <select
                        value={language}
                        onChange={handleLanguageChange}
                        className="w-full p-4 border rounded-xl shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-12"
                    >
                        <option value="English">English</option>
                        <option value="Hindi">Hindi</option>
                        <option value="Tamil">Tamil</option>
                        <option value="Spanish">Spanish</option>
                    </select>
                </div>
                <button type="submit" className="w-full bg-blue-500 text-white py-4 rounded-xl shadow-lg hover:bg-blue-600 transition duration-300">
                    Update Settings
                </button>
            </form>
        </section>
    );
}

export default SettingsInfo;