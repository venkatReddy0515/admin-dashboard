import React, { useState } from 'react';

function Maintenance() {
  const [status, setStatus] = useState('online');

  const [maintenanceEnabled, setMaintenanceEnabled] = useState(false);
  const [maintenanceMessage, setMaintenanceMessage] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');

  const handleSimulateStatus = () => {
    if (status === 'online') {
      setStatus('degraded');
    } else if (status === 'degraded') {
      setStatus('offline');
    } else {
      setStatus('online');
    }
  };

  const handleToggle = () => {
    setMaintenanceEnabled(!maintenanceEnabled);
  };

 
  const handleSave = () => {
    console.log('Maintenance Mode Enabled:', maintenanceEnabled);
    console.log('Maintenance Message:', maintenanceMessage);
    console.log('Start Time:', startTime);
    console.log('End Time:', endTime);
    alert('Maintenance settings saved.');
  };

  const getStatusIndicator = () => {
    let indicatorClass = 'inline-block w-3 h-3 rounded-full mr-2';
    if (status === 'online') return <span className={`${indicatorClass} bg-green-500`}></span>;
    if (status === 'degraded') return <span className={`${indicatorClass} bg-yellow-500`}></span>;
    if (status === 'offline') return <span className={`${indicatorClass} bg-red-500`}></span>;
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Site Status & Maintenance Settings</h1>
        
        {/* Web Status Section */}
        <div className="bg-white shadow rounded mb-6">
          <div className="border-b px-4 py-2 font-semibold">
            Web Status
          </div>
          <div className="p-4">
            <p className="mb-4 flex items-center">
              {getStatusIndicator()}
              <span className="capitalize">{status}</span>
            </p>
            <button 
              onClick={handleSimulateStatus} 
              className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition">
              Simulate Status Change
            </button>
          </div>
        </div>

        <div className="bg-white shadow rounded">
          <div className="border-b px-4 py-2 font-semibold">
            Maintenance Mode
          </div>
          <div className="p-4">
            <div className="flex items-center mb-4">
              <input
                type="checkbox"
                id="maintenanceToggle"
                checked={maintenanceEnabled}
                onChange={handleToggle}
                className="mr-2 form-checkbox h-5 w-5 text-blue-600"
              />
              <label htmlFor="maintenanceToggle">Enable Maintenance Mode</label>
            </div>
            {maintenanceEnabled && (
              <div id="maintenanceSettings">
                <div className="mb-4">
                  <label htmlFor="maintenanceMessage" className="block text-sm font-medium mb-1">
                    Custom Maintenance Message:
                  </label>
                  <textarea
                    id="maintenanceMessage"
                    rows="3"
                    className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter maintenance details, estimated downtime, contact info, etc."
                    value={maintenanceMessage}
                    onChange={(e) => setMaintenanceMessage(e.target.value)}
                  ></textarea>
                </div>
                <div className="mb-4">
                  <label htmlFor="startTime" className="block text-sm font-medium mb-1">
                    Start Time:
                  </label>
                  <input
                    type="datetime-local"
                    id="startTime"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div className="mb-4">
                  <label htmlFor="endTime" className="block text-sm font-medium mb-1">
                    End Time:
                  </label>
                  <input
                    type="datetime-local"
                    id="endTime"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <button 
                  onClick={handleSave} 
                  className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition">
                  Save Maintenance Settings
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Maintenance