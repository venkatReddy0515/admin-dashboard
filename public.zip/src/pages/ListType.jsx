// import React from "react";
// import ReactQuill from "react-quill";
// import "react-quill/dist/quill.snow.css";

// import {
//   AiOutlineBold,
//   AiOutlineItalic,
//   AiOutlineUnderline,
//   AiOutlineAlignLeft,
//   AiOutlineAlignCenter,
//   AiOutlineAlignRight,
//   AiOutlineOrderedList,
//   AiOutlineUnorderedList,
//   AiOutlineUndo,
//   AiOutlineRedo,
//   AiOutlinePaperClip,
//   AiOutlineLink,
//   AiOutlineSmile,
//   AiOutlinePicture,
//   AiOutlineDelete,
// } from "react-icons/ai";

// function ListType() {
//   // Custom toolbar
//   const modules = {
//     toolbar: {
//       container: "#toolbar",
//     },
//   };

//   return (
//     <div className="editor-container">
//       {/* Custom Toolbar */}
      
//       <div id="toolbar">
//         <button className="ql-bold">
//           <AiOutlineBold />
//         </button>
//         <button className="ql-italic">
//           <AiOutlineItalic />
//         </button>
//         <button className="ql-underline">
//           <AiOutlineUnderline />
//         </button>
//         <button className="ql-align" value="left">
//           <AiOutlineAlignLeft />
//         </button>
//         <button className="ql-align" value="center">
//           <AiOutlineAlignCenter />
//         </button>
//         <button className="ql-align" value="right">
//           <AiOutlineAlignRight />
//         </button>
//         <button className="ql-list" value="ordered">
//           <AiOutlineOrderedList />
//         </button>
//         <button className="ql-list" value="bullet">
//           <AiOutlineUnorderedList />
//         </button>
//         <button className="ql-undo">
//           <AiOutlineUndo />
//         </button>
//         <button className="ql-redo">
//           <AiOutlineRedo />
//         </button>
//         <button>
//           <AiOutlinePaperClip />
//         </button>
//         <button>
//           <AiOutlineLink />
//         </button>
//         <button>
//           <AiOutlineSmile />
//         </button>
//         <button>
//           <AiOutlinePicture />
//         </button>
//         <button>
//           <AiOutlineDelete />
//         </button>
//       </div>

      
//     </div>
//   );
// }

// export default ListType;
