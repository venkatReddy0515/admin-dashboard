function FaqsSection(){
    return(
        <>
            <div className="div-faqs">
                <div className="display-options">
                    
                </div>
            </div>
        </>
    )
}
export default FaqsSection